'use strict';

function sendToTab(msg) {
  chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
    if (!tabs[0]) return;
    const url = tabs[0].url || '';
    if (!url.includes('youtube.com')) return;
    chrome.tabs.sendMessage(tabs[0].id, msg, () => { chrome.runtime.lastError; });
  });
}

// ── Load settings ──────────────────────────────────────────────
const keys = ['showBadge','screenshotKey','playbackSpeedButtons','autoPause','watermark'];
chrome.storage.sync.get(keys, (r) => {
  document.getElementById('toggleBadge').checked     = r.showBadge !== false;
  document.getElementById('toggleKey').checked       = !!r.screenshotKey;
  document.getElementById('toggleSpeed').checked     = !!r.playbackSpeedButtons;
  document.getElementById('togglePause').checked     = !!r.autoPause;
  document.getElementById('toggleWatermark').checked = !!r.watermark;
});

// ── Toggle handlers ────────────────────────────────────────────
function bindToggle(id, key, onMsg) {
  document.getElementById(id).addEventListener('change', function() {
    chrome.storage.sync.set({ [key]: this.checked });
    if (onMsg) sendToTab(onMsg(this.checked));
  });
}

bindToggle('toggleBadge', 'showBadge', (v) => ({ type: 'TOGGLE_BADGE', show: v }));
bindToggle('toggleKey',   'screenshotKey');
bindToggle('toggleSpeed', 'playbackSpeedButtons');
bindToggle('togglePause', 'autoPause');
bindToggle('toggleWatermark', 'watermark');

// ── Quick action buttons ───────────────────────────────────────
document.getElementById('qShot').addEventListener('click', () => {
  sendToTab({ type: 'CAPTURE_NOW' });
  window.close();
});
document.getElementById('qAnnotate').addEventListener('click', () => {
  sendToTab({ type: 'OPEN_ANNOTATE' });
  window.close();
});
document.getElementById('qBurst').addEventListener('click', () => {
  sendToTab({ type: 'START_BURST' });
  window.close();
});

// ── Footer links ───────────────────────────────────────────────
document.getElementById('optionsLink').addEventListener('click', () => {
  chrome.runtime.openOptionsPage();
});
document.getElementById('privacyLink').addEventListener('click', () => {
  chrome.tabs.create({ url: chrome.runtime.getURL('privacy.html') });
});
