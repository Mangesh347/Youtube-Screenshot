'use strict';

// ──────────────────────────────────────────────────────────────
//  TubeShot Pro  –  page.js  (v2.0)
// ──────────────────────────────────────────────────────────────

// ── State ──────────────────────────────────────────────────────
const TS = {
  showBadge          : true,
  screenshotKey      : false,
  playbackSpeedBtns  : false,
  format             : 'png',
  functionality      : 0,   // 0=save 1=copy 2=both
  watermark          : false,
  watermarkText      : '',
  burstCount         : 5,
  timerEnabled       : false,
  timerInterval      : 10,  // seconds
  autoPause          : false,
  annotationsEnabled : true,
};

let activePBRButton;
let isAppended   = false;
let burstActive  = false;
let burstTimer   = null;
let timerIntervalId = null;
let annoDrawing  = false;
let annoTool     = 'pen'; // pen | arrow | rect | text | eraser
let annoColor    = '#ff4444';
let annoSize     = 4;
let annoPoints   = [];
let annoStartX   = 0, annoStartY = 0;
let annoSnapshotData = null; // canvas snapshot for shapes
let frozenFrame  = null;     // ImageData of the frozen frame

// ── Load all settings ──────────────────────────────────────────
chrome.storage.sync.get([
  'showBadge','screenshotKey','playbackSpeedButtons','screenshotFunctionality',
  'screenshotFileFormat','watermark','watermarkText','burstCount',
  'timerEnabled','timerInterval','autoPause','annotationsEnabled'
], (r) => {
  TS.showBadge         = r.showBadge !== false;
  TS.screenshotKey     = !!r.screenshotKey;
  TS.playbackSpeedBtns = !!r.playbackSpeedButtons;
  TS.functionality     = r.screenshotFunctionality ?? 0;
  TS.format            = r.screenshotFileFormat    || 'png';
  TS.watermark         = !!r.watermark;
  TS.watermarkText     = r.watermarkText           || '';
  TS.burstCount        = parseInt(r.burstCount)    || 5;
  TS.timerEnabled      = !!r.timerEnabled;
  TS.timerInterval     = parseInt(r.timerInterval) || 10;
  TS.autoPause         = !!r.autoPause;
  TS.annotationsEnabled= r.annotationsEnabled !== false;
  if (!TS.showBadge) screenshotBtn.style.display = 'none';
  if (TS.timerEnabled) startAutoTimer();
});

// ── Helper: get video element ──────────────────────────────────
function getVideo() { return document.querySelector('video.video-stream, video'); }

// ── Helper: get video title ────────────────────────────────────
function getTitle() {
  const el = document.querySelector('h1.ytd-video-primary-info-renderer yt-formatted-string, h1.title');
  return el ? el.textContent.trim() : 'YouTube';
}

// ── Helper: format timestamp ───────────────────────────────────
function fmtTime(secs) {
  const h = Math.floor(secs / 3600);
  const m = Math.floor((secs % 3600) / 60);
  const s = Math.floor(secs % 60);
  return [h > 0 ? String(h).padStart(2,'0') : null, String(m).padStart(2,'0'), String(s).padStart(2,'0')]
    .filter(Boolean).join('-');
}

// ── Flash effect ───────────────────────────────────────────────
function doFlash() {
  const f = document.createElement('div');
  f.className = 'ts-flash';
  document.body.appendChild(f);
  setTimeout(() => f.remove(), 400);
}

// ── Toast notification ─────────────────────────────────────────
let toastEl = null;
function showToast(msg, color = '#ff4444') {
  if (!toastEl) {
    toastEl = document.createElement('div');
    toastEl.className = 'ts-toast';
    document.body.appendChild(toastEl);
  }
  toastEl.style.borderLeftColor = color;
  toastEl.textContent = msg;
  toastEl.classList.add('show');
  clearTimeout(toastEl._t);
  toastEl._t = setTimeout(() => toastEl.classList.remove('show'), 2500);
}

// ── Build canvas from video ────────────────────────────────────
function buildCanvas(extraDraw) {
  const player = getVideo();
  if (!player) return null;
  const canvas = document.createElement('canvas');
  canvas.width  = player.videoWidth  || player.clientWidth;
  canvas.height = player.videoHeight || player.clientHeight;
  const ctx = canvas.getContext('2d');
  ctx.drawImage(player, 0, 0, canvas.width, canvas.height);

  // Watermark
  if (TS.watermark && TS.watermarkText) {
    ctx.font = 'bold 20px Arial';
    ctx.fillStyle = 'rgba(255,255,255,0.6)';
    ctx.textAlign = 'right';
    ctx.fillText(TS.watermarkText, canvas.width - 12, canvas.height - 12);
  }

  // Timestamp overlay
  if (TS.showTimestamp) {
    const ts = fmtTime(player.currentTime);
    ctx.font = 'bold 18px monospace';
    ctx.fillStyle = 'rgba(0,0,0,0.55)';
    ctx.fillRect(8, 8, 110, 28);
    ctx.fillStyle = '#fff';
    ctx.textAlign = 'left';
    ctx.fillText('⏱ ' + ts, 14, 29);
  }

  if (extraDraw) extraDraw(ctx, canvas);
  return canvas;
}

// ── File download helper ────────────────────────────────────────
function downloadCanvas(canvas, suffix = '') {
  const ext  = TS.format === 'jpeg' ? 'jpg' : TS.format;
  const mime = 'image/' + TS.format;
  const title = getTitle().replace(/[<>:"/\\|?*]/g, '').slice(0, 80);
  const player = getVideo();
  const ts = player ? fmtTime(player.currentTime) : '0';
  const filename = `${title} ${ts}${suffix}.${ext}`;
  canvas.toBlob((blob) => {
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url; a.download = filename; a.click();
    setTimeout(() => URL.revokeObjectURL(url), 5000);
  }, mime, 0.95);
}

// ── Clipboard helper ────────────────────────────────────────────
async function copyCanvas(canvas) {
  return new Promise(resolve => {
    canvas.toBlob(async (blob) => {
      try { await navigator.clipboard.write([new ClipboardItem({'image/png': blob})]); }
      catch(e) {}
      resolve();
    }, 'image/png');
  });
}

// ── Core: capture one screenshot ──────────────────────────────
async function captureScreenshot(suffix = '', extraDraw = null) {
  const player = getVideo();
  if (!player) { showToast('⚠️ No video found'); return; }

  // Auto-pause
  if (TS.autoPause && !player.paused) player.pause();

  const canvas = buildCanvas(extraDraw);
  if (!canvas) return;

  doFlash();

  if (TS.functionality === 0) {
    downloadCanvas(canvas, suffix);
    showToast('📸 Screenshot saved!', '#00cc88');
  } else if (TS.functionality === 1) {
    await copyCanvas(canvas);
    showToast('📋 Copied to clipboard!', '#60a5fa');
  } else {
    await copyCanvas(canvas);
    downloadCanvas(canvas, suffix);
    showToast('📸 Saved + Copied!', '#00cc88');
  }
}

// ── Burst mode ─────────────────────────────────────────────────
const burstIndicator = document.createElement('div');
burstIndicator.id = 'ts-burst-indicator';
burstIndicator.textContent = '● BURST';
document.body.appendChild(burstIndicator);

function startBurst() {
  if (burstActive) { stopBurst(); return; }
  burstActive = true;
  burstIndicator.style.display = 'block';
  let count = 0;
  burstTimer = setInterval(() => {
    captureScreenshot(`_burst${count+1}`);
    count++;
    if (count >= TS.burstCount) stopBurst();
  }, 600);
}

function stopBurst() {
  burstActive = false;
  clearInterval(burstTimer);
  burstIndicator.style.display = 'none';
  showToast(`✅ Burst done – ${TS.burstCount} shots!`, '#fbbf24');
}

// ── Auto-timer ─────────────────────────────────────────────────
const timerDisplay = document.createElement('div');
timerDisplay.id = 'ts-timer-display';
document.body.appendChild(timerDisplay);

let timerCountdown = 0;

function startAutoTimer() {
  stopAutoTimer();
  timerDisplay.style.display = 'block';
  timerCountdown = TS.timerInterval;
  timerDisplay.textContent = '⏱ ' + timerCountdown + 's';
  timerIntervalId = setInterval(() => {
    timerCountdown--;
    timerDisplay.textContent = '⏱ ' + timerCountdown + 's';
    if (timerCountdown <= 0) {
      captureScreenshot('_auto');
      timerCountdown = TS.timerInterval;
    }
  }, 1000);
}

function stopAutoTimer() {
  clearInterval(timerIntervalId);
  timerDisplay.style.display = 'none';
}

// ── Annotation overlay ─────────────────────────────────────────
const annoOverlay = document.createElement('div');
annoOverlay.id = 'ts-annotation-overlay';

const annoCanvas = document.createElement('canvas');
annoCanvas.id = 'ts-anno-canvas';

const annoToolbar = document.createElement('div');
annoToolbar.id = 'ts-anno-toolbar';
annoToolbar.innerHTML = `
  <button class="ts-anno-tool active" data-tool="pen"    title="Pen">✏️</button>
  <button class="ts-anno-tool"        data-tool="arrow"  title="Arrow">➡️</button>
  <button class="ts-anno-tool"        data-tool="rect"   title="Rectangle">⬜</button>
  <button class="ts-anno-tool"        data-tool="circle" title="Circle">⭕</button>
  <button class="ts-anno-tool"        data-tool="text"   title="Text">T</button>
  <button class="ts-anno-tool"        data-tool="eraser" title="Eraser">🧹</button>
  <div class="ts-anno-sep"></div>
  <input type="color" id="ts-anno-color" value="#ff4444" title="Color">
  <input type="range" id="ts-anno-size" min="1" max="20" value="4" title="Size">
  <div class="ts-anno-sep"></div>
  <button class="ts-anno-tool" id="ts-anno-undo"  title="Undo">↩️</button>
  <button class="ts-anno-tool" id="ts-anno-clear" title="Clear">🗑</button>
  <div class="ts-anno-sep"></div>
  <button class="ts-anno-tool" id="ts-anno-save"  title="Save">💾</button>
  <button class="ts-anno-tool" id="ts-anno-close" title="Close">✕</button>
`;

annoOverlay.appendChild(annoCanvas);
annoOverlay.appendChild(annoToolbar);
document.body.appendChild(annoOverlay);

// History stack for undo
let annoHistory = [];

function openAnnotation() {
  const player = getVideo();
  if (!player) { showToast('⚠️ No video found'); return; }
  if (TS.autoPause && !player.paused) player.pause();

  annoCanvas.width  = window.innerWidth;
  annoCanvas.height = window.innerHeight;

  // Draw video frame as background
  const ctx = annoCanvas.getContext('2d');
  const vr  = player.getBoundingClientRect();
  ctx.clearRect(0, 0, annoCanvas.width, annoCanvas.height);

  // Dim background
  ctx.fillStyle = 'rgba(0,0,0,0.5)';
  ctx.fillRect(0, 0, annoCanvas.width, annoCanvas.height);

  // Draw actual video into canvas area
  ctx.drawImage(player, vr.left, vr.top, vr.width, vr.height);

  // Save snapshot
  annoSnapshotData = ctx.getImageData(0, 0, annoCanvas.width, annoCanvas.height);
  annoHistory = [annoSnapshotData];

  annoOverlay.classList.add('visible');
}

function closeAnnotation() {
  annoOverlay.classList.remove('visible');
  annoHistory = [];
}

function saveAnnotation() {
  const ctx = annoCanvas.getContext('2d');
  const player = getVideo();
  const vr = player ? player.getBoundingClientRect() : {left:0,top:0,width:annoCanvas.width,height:annoCanvas.height};

  // Crop to video region only
  const out = document.createElement('canvas');
  out.width  = vr.width;
  out.height = vr.height;
  out.getContext('2d').drawImage(annoCanvas, vr.left, vr.top, vr.width, vr.height, 0, 0, vr.width, vr.height);
  downloadCanvas(out, '_annotated');
  showToast('💾 Annotated screenshot saved!', '#00cc88');
  closeAnnotation();
}

// Toolbar events
annoToolbar.querySelectorAll('[data-tool]').forEach(btn => {
  btn.addEventListener('click', () => {
    annoTool = btn.dataset.tool;
    annoToolbar.querySelectorAll('[data-tool]').forEach(b => b.classList.remove('active'));
    btn.classList.add('active');
  });
});
document.getElementById('ts-anno-color').addEventListener('input', e => annoColor = e.target.value);
document.getElementById('ts-anno-size').addEventListener('input',  e => annoSize  = parseInt(e.target.value));
document.getElementById('ts-anno-undo').addEventListener('click', () => {
  if (annoHistory.length > 1) {
    annoHistory.pop();
    annoCanvas.getContext('2d').putImageData(annoHistory[annoHistory.length-1], 0, 0);
  }
});
document.getElementById('ts-anno-clear').addEventListener('click', () => {
  if (annoHistory.length) {
    annoCanvas.getContext('2d').putImageData(annoHistory[0], 0, 0);
    annoHistory = [annoHistory[0]];
  }
});
document.getElementById('ts-anno-save').addEventListener('click', saveAnnotation);
document.getElementById('ts-anno-close').addEventListener('click', closeAnnotation);

// Drawing events
annoCanvas.addEventListener('mousedown', (e) => {
  annoDrawing = true;
  annoStartX = e.clientX; annoStartY = e.clientY;
  if (annoTool === 'pen' || annoTool === 'eraser') {
    annoPoints = [{x: e.clientX, y: e.clientY}];
  }
  // Save snapshot for shape preview
  annoSnapshotData = annoCanvas.getContext('2d').getImageData(0, 0, annoCanvas.width, annoCanvas.height);
});

annoCanvas.addEventListener('mousemove', (e) => {
  if (!annoDrawing) return;
  const ctx = annoCanvas.getContext('2d');
  const x = e.clientX, y = e.clientY;

  if (annoTool === 'pen' || annoTool === 'eraser') {
    annoPoints.push({x, y});
    ctx.beginPath();
    ctx.strokeStyle = annoTool === 'eraser' ? 'rgba(0,0,0,0)' : annoColor;
    ctx.lineWidth   = annoTool === 'eraser' ? annoSize * 3 : annoSize;
    ctx.lineCap = 'round'; ctx.lineJoin = 'round';
    if (annoTool === 'eraser') ctx.globalCompositeOperation = 'destination-out';
    const pts = annoPoints;
    if (pts.length >= 2) {
      ctx.moveTo(pts[pts.length-2].x, pts[pts.length-2].y);
      ctx.lineTo(pts[pts.length-1].x, pts[pts.length-1].y);
    }
    ctx.stroke();
    ctx.globalCompositeOperation = 'source-over';
  } else {
    // Restore snapshot then draw preview
    ctx.putImageData(annoSnapshotData, 0, 0);
    ctx.strokeStyle = annoColor;
    ctx.fillStyle   = annoColor;
    ctx.lineWidth   = annoSize;
    ctx.beginPath();
    if (annoTool === 'rect') {
      ctx.strokeRect(annoStartX, annoStartY, x - annoStartX, y - annoStartY);
    } else if (annoTool === 'circle') {
      const rx = Math.abs(x - annoStartX) / 2, ry = Math.abs(y - annoStartY) / 2;
      ctx.ellipse(annoStartX + (x-annoStartX)/2, annoStartY + (y-annoStartY)/2, rx, ry, 0, 0, 2*Math.PI);
      ctx.stroke();
    } else if (annoTool === 'arrow') {
      drawArrow(ctx, annoStartX, annoStartY, x, y);
    }
  }
});

annoCanvas.addEventListener('mouseup', (e) => {
  if (!annoDrawing) return;
  annoDrawing = false;
  const ctx = annoCanvas.getContext('2d');
  if (annoTool === 'text') {
    const text = prompt('Enter text:');
    if (text) {
      ctx.font = `bold ${Math.max(annoSize * 4, 16)}px Arial`;
      ctx.fillStyle = annoColor;
      ctx.fillText(text, annoStartX, annoStartY);
    }
  }
  annoHistory.push(ctx.getImageData(0, 0, annoCanvas.width, annoCanvas.height));
  if (annoHistory.length > 20) annoHistory.shift();
});

function drawArrow(ctx, x1, y1, x2, y2) {
  const angle = Math.atan2(y2 - y1, x2 - x1);
  const len = 14;
  ctx.moveTo(x1, y1); ctx.lineTo(x2, y2); ctx.stroke();
  ctx.beginPath();
  ctx.moveTo(x2, y2);
  ctx.lineTo(x2 - len * Math.cos(angle - Math.PI/7), y2 - len * Math.sin(angle - Math.PI/7));
  ctx.lineTo(x2 - len * Math.cos(angle + Math.PI/7), y2 - len * Math.sin(angle + Math.PI/7));
  ctx.closePath(); ctx.fill();
}

// ── Player control bar buttons ─────────────────────────────────
function makeBtn(icon, title, cls) {
  const btn = document.createElement('button');
  btn.className = `ts-screenshot-btn ytp-button ${cls || ''}`;
  btn.title = title;
  btn.innerHTML = icon;
  return btn;
}

// Screenshot button (camera SVG)
const screenshotBtn = makeBtn(`
  <svg height="22" width="22" viewBox="0 0 24 24" fill="white">
    <path d="M21 5h-3.17l-1.84-2H8.01L6.17 5H3C1.9 5 1 5.9 1 7v12c0 1.1.9 2 2 2h18c1.1 0 2-.9 2-2V7c0-1.1-.9-2-2-2zm-9 13c-2.76 0-5-2.24-5-5s2.24-5 5-5 5 2.24 5 5-2.24 5-5 5zm0-8c-1.66 0-3 1.34-3 3s1.34 3 3 3 3-1.34 3-3-1.34-3-3-3z"/>
  </svg>`, 'TubeShot: Screenshot (P)', 'ts-ss-btn');
screenshotBtn.onclick = () => captureScreenshot();

// Annotate button
const annotateBtn = makeBtn(`
  <svg height="22" width="22" viewBox="0 0 24 24" fill="white">
    <path d="M3 17.25V21h3.75L17.81 9.94l-3.75-3.75L3 17.25zm17.71-10.21a1 1 0 0 0 0-1.41l-2.34-2.34a1 1 0 0 0-1.41 0l-1.83 1.83 3.75 3.75 1.83-1.83z"/>
  </svg>`, 'TubeShot: Annotate & Screenshot', 'ts-anno-open-btn');
annotateBtn.onclick = openAnnotation;

// Burst button
const burstBtn = makeBtn(`
  <svg height="22" width="22" viewBox="0 0 24 24" fill="white">
    <path d="M4 8H2v12c0 1.1.9 2 2 2h12v-2H4V8zm16-4H8C6.9 4 6 4.9 6 6v12c0 1.1.9 2 2 2h12c1.1 0 2-.9 2-2V6c0-1.1-.9-2-2-2zm-8 12.5v-9l6 4.5-6 4.5z"/>
  </svg>`, 'TubeShot: Burst Mode (3 shots)', 'ts-burst-btn');
burstBtn.onclick = startBurst;

// Speed buttons
function makeSpeedBtn(label, rate) {
  const btn = document.createElement('button');
  btn.className = 'ytp-button SYText';
  btn.innerHTML = label;
  btn.title = `Set speed ${rate}×`;
  btn.onclick = () => {
    const video = getVideo();
    if (video) video.playbackRate = rate;
    if (activePBRButton) activePBRButton.classList.remove('SYTactive');
    btn.classList.add('SYTactive');
    activePBRButton = btn;
    showToast(`⚡ Speed: ${rate}×`, '#fbbf24');
  };
  return btn;
}
const speed05Btn = makeSpeedBtn('0.5×', 0.5);
const speed1Btn  = makeSpeedBtn('1×',   1);
const speed15Btn = makeSpeedBtn('1.5×', 1.5);
const speed2Btn  = makeSpeedBtn('2×',   2);
const speed3Btn  = makeSpeedBtn('3×',   3);
activePBRButton = speed1Btn;

// ── Inject buttons into YT player ─────────────────────────────
function injectButtons() {
  if (!TS.showBadge) return;
  const bar = document.querySelector('.ytp-right-controls');
  if (!bar) { isAppended = false; return; }
  if (isAppended && bar.contains(screenshotBtn)) return;

  const ref = bar.childNodes[bar.childNodes.length - 2] || null;
  bar.insertBefore(screenshotBtn, ref);
  bar.insertBefore(annotateBtn, ref);
  bar.insertBefore(burstBtn, ref);

  if (TS.playbackSpeedBtns) {
    [speed3Btn, speed2Btn, speed15Btn, speed1Btn, speed05Btn].forEach(b => bar.prepend(b));
    // Highlight current rate
    const rate = getVideo()?.playbackRate || 1;
    const map = {0.5: speed05Btn, 1: speed1Btn, 1.5: speed15Btn, 2: speed2Btn, 3: speed3Btn};
    if (map[rate]) { map[rate].classList.add('SYTactive'); activePBRButton = map[rate]; }
  }

  isAppended = true;
}

injectButtons();

// ── MutationObserver: re-inject after SPA navigation ──────────
new MutationObserver(() => {
  if (!document.querySelector('.ytp-right-controls')?.contains(screenshotBtn)) {
    isAppended = false;
    injectButtons();
  }
}).observe(document.body, { childList: true, subtree: true });

// ── Keyboard shortcuts ─────────────────────────────────────────
document.addEventListener('keydown', (e) => {
  const tag = document.activeElement?.tagName;
  if (tag === 'INPUT' || tag === 'TEXTAREA' || document.activeElement?.isContentEditable) return;

  // Speed keys
  if (TS.playbackSpeedBtns) {
    const keyMap = {'1': speed1Btn, '2': speed2Btn, '3': speed3Btn};
    if (keyMap[e.key]) { keyMap[e.key].click(); e.preventDefault(); return; }
  }

  if (e.key === 'p' && TS.screenshotKey) { captureScreenshot(); e.preventDefault(); }
  if (e.key === 'a' && TS.annotationsEnabled && e.ctrlKey) { openAnnotation(); e.preventDefault(); }
  if (e.key === 'Escape' && annoOverlay.classList.contains('visible')) closeAnnotation();
});

// ── Message listener (from popup) ─────────────────────────────
chrome.runtime.onMessage.addListener((msg) => {
  switch (msg.type) {
    case 'TOGGLE_BADGE':
      TS.showBadge = msg.show;
      screenshotBtn.style.display = msg.show ? '' : 'none';
      annotateBtn.style.display   = msg.show ? '' : 'none';
      burstBtn.style.display      = msg.show ? '' : 'none';
      break;
    case 'CAPTURE_NOW': captureScreenshot(); break;
    case 'OPEN_ANNOTATE': openAnnotation(); break;
    case 'START_BURST': startBurst(); break;
    case 'TOGGLE_TIMER':
      TS.timerEnabled = msg.enabled;
      TS.timerInterval = msg.interval || TS.timerInterval;
      if (TS.timerEnabled) startAutoTimer(); else stopAutoTimer();
      break;
    case 'UPDATE_SETTINGS':
      Object.assign(TS, msg.settings);
      break;
  }
});
