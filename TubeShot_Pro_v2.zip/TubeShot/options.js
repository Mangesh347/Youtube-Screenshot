'use strict';

const KEYS = [
  'screenshotFileFormat','screenshotFunctionality','autoPause','watermarkText',
  'burstCount','timerEnabled','timerInterval','playbackSpeedButtons','screenshotKey'
];

// ── Load ──────────────────────────────────────────────────────
chrome.storage.sync.get(KEYS, (r) => {
  document.getElementById('optFormat').value         = r.screenshotFileFormat    || 'png';
  document.getElementById('optAutoPause').checked    = !!r.autoPause;
  document.getElementById('optWatermarkText').value  = r.watermarkText           || '';
  document.getElementById('optBurst').value          = r.burstCount              || 5;
  document.getElementById('optTimer').checked        = !!r.timerEnabled;
  document.getElementById('optTimerInterval').value  = r.timerInterval           || 10;
  document.getElementById('optSpeed').checked        = !!r.playbackSpeedButtons;
  document.getElementById('optKey').checked          = !!r.screenshotKey;

  // Radio buttons for action
  const action = r.screenshotFunctionality ?? 0;
  document.querySelectorAll('#optAction .radio-option').forEach(el => {
    el.classList.toggle('selected', el.dataset.val == action);
  });
});

// ── Radio toggle ───────────────────────────────────────────────
document.querySelectorAll('#optAction .radio-option').forEach(el => {
  el.addEventListener('click', () => {
    document.querySelectorAll('#optAction .radio-option').forEach(e => e.classList.remove('selected'));
    el.classList.add('selected');
  });
});

// ── Save ──────────────────────────────────────────────────────
document.getElementById('saveBtn').addEventListener('click', () => {
  const selectedAction = document.querySelector('#optAction .selected');
  const settings = {
    screenshotFileFormat   : document.getElementById('optFormat').value,
    screenshotFunctionality: parseInt(selectedAction?.dataset.val ?? 0),
    autoPause              : document.getElementById('optAutoPause').checked,
    watermark              : document.getElementById('optWatermarkText').value.length > 0,
    watermarkText          : document.getElementById('optWatermarkText').value,
    burstCount             : parseInt(document.getElementById('optBurst').value),
    timerEnabled           : document.getElementById('optTimer').checked,
    timerInterval          : parseInt(document.getElementById('optTimerInterval').value),
    playbackSpeedButtons   : document.getElementById('optSpeed').checked,
    screenshotKey          : document.getElementById('optKey').checked,
  };

  chrome.storage.sync.set(settings, () => {
    const msg = document.getElementById('savedMsg');
    msg.textContent = '✅ Settings saved!';
    setTimeout(() => msg.textContent = '', 2500);
  });
});
